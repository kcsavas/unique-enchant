# Unique Enchants (Fabric 1.21.11)

Mod **côté serveur** : les joueurs peuvent se connecter avec un Minecraft vanilla.

## Compiler
1. Java 21 + Gradle 9.2+ (le plus simple : copier `gradlew`, `gradlew.bat` et le dossier `gradle/`
   depuis le fabric-example-mod officiel, ou lancer `gradle wrapper --gradle-version 9.2.1`).
2. `./gradlew build`
3. Le jar est dans `build/libs/uniqueenchants-1.0.0.jar` -> dossier `mods/` (avec Fabric API 0.141.3+1.21.11).

## Config : `config/uniqueenchants.properties`
- `unique_per_level` (true) : Protection 4 pris mais Protection 3 reste dispo. `false` = unique tout court.
- `infinite_food` (true) : Infinity sur un consommable = jamais consommé.
- `explosion_power` (1.2) : 0 = particules seulement.
- `explosion_break_blocks` (false)

## Enchantements pris
Fichier `uniqueenchants_claims.txt` dans le dossier du monde (une ligne `clé=joueur`).
Pour libérer un enchantement : arrête le serveur, supprime la ligne, relance.
