package fr.uniqueenchants;

import fr.uniqueenchants.mixin.ItemCombinerMenuAccessor;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public final class AnvilLogic {

    public static final String MSG_USED_BOOK = "✦ Cet enchantement a déjà été utilisé... le livre se désintègre !";
    public static final String MSG_DENIED = "Cet enchantement est déjà pris, impossible de le copier.";

    private AnvilLogic() {}

    public record Built(ItemStack result, int cost) {}

    /** Enchantements d'un item (stockés si c'est un livre). */
    public static ItemEnchantments enchantsOf(ItemStack stack) {
        if (stack.isEmpty()) return ItemEnchantments.EMPTY;
        return EnchantmentHelper.getEnchantmentsForCrafting(stack);
    }

    /**
     * Résultat d'enclume "tout est permis" : n'importe quel enchantement sur n'importe quel item.
     * Retourne null si on laisse la vanilla faire.
     */
    public static Built build(ItemStack left, ItemStack right, ItemStack vanilla, String itemName) {
        if (left.isEmpty() || right.isEmpty() || left.is(Items.ENCHANTED_BOOK)) return null;

        ItemEnchantments add = enchantsOf(right);
        if (add.isEmpty()) return null;

        // Anti-duplication : pas d'enchantement unique sur une pile entière
        if (left.getCount() > 1) return new Built(ItemStack.EMPTY, 0);

        ItemEnchantments base = enchantsOf(left);
        ItemStack result = vanilla.isEmpty() ? left.copy() : vanilla.copy();

        Map<Holder<Enchantment>, Integer> merged = new LinkedHashMap<>();
        int cost = 1;
        for (Object2IntMap.Entry<Holder<Enchantment>> e : add.entrySet()) {
            Holder<Enchantment> h = e.getKey();
            int l = e.getIntValue();
            int cur = base.getLevel(h);
            int m = (cur == l && l < h.value().getMaxLevel()) ? l + 1 : Math.max(cur, l);
            merged.put(h, m);
            cost += Math.max(0, m - cur);
        }
        EnchantmentHelper.updateEnchantments(result, mut -> merged.forEach(mut::set));

        // Si la vanilla n'a rien proposé, on gère le renommage nous-mêmes
        if (vanilla.isEmpty() && itemName != null && !itemName.isBlank()) {
            result.set(DataComponents.CUSTOM_NAME, Component.literal(itemName));
        }
        return new Built(result, Math.min(cost, 39));
    }

    /** Enchantements "consommés" : ceux du slot de droite + les nouveaux du résultat. */
    public static Set<String> consumedKeys(ItemStack left, ItemStack right, ItemStack result) {
        Set<String> keys = new LinkedHashSet<>();
        for (Object2IntMap.Entry<Holder<Enchantment>> e : enchantsOf(right).entrySet())
            keys.add(Claims.keyOf(e.getKey(), e.getIntValue()));

        ItemEnchantments before = enchantsOf(left);
        for (Object2IntMap.Entry<Holder<Enchantment>> e : enchantsOf(result).entrySet())
            if (before.getLevel(e.getKey()) != e.getIntValue())
                keys.add(Claims.keyOf(e.getKey(), e.getIntValue()));
        return keys;
    }

    /**
     * Appelé quand le joueur clique sur le slot résultat de l'enclume.
     * Retourne true si le clic doit être annulé (enchantement déjà utilisé).
     */
    public static boolean blockIfUsed(AnvilMenu menu, ServerPlayer player) {
        ItemStack result = menu.getSlot(2).getItem();
        if (result.isEmpty()) return false;

        ItemStack left = menu.getSlot(0).getItem();
        ItemStack right = menu.getSlot(1).getItem();
        Set<String> keys = consumedKeys(left, right, result);
        if (keys.isEmpty() || !Claims.anyClaimed(keys)) return false;

        if (right.is(Items.ENCHANTED_BOOK)) {
            double[] at = anvilPosition(menu, player);
            ItemStack book = right.copyWithCount(1);
            menu.getSlot(1).set(ItemStack.EMPTY);
            player.sendSystemMessage(Component.literal(MSG_USED_BOOK).withStyle(ChatFormatting.RED));
            Animations.startBookExplosion(player, at[0], at[1], at[2], book);
        } else {
            player.sendSystemMessage(Component.literal(MSG_DENIED).withStyle(ChatFormatting.RED));
        }
        return true;
    }

    /** Au-dessus de l'enclume, ou devant le joueur si on ne la trouve pas. */
    private static double[] anvilPosition(AnvilMenu menu, ServerPlayer player) {
        double[] at = new double[3];
        boolean[] found = {false};
        ((ItemCombinerMenuAccessor) (Object) menu).getAccess().execute((level, pos) -> {
            at[0] = pos.getX() + 0.5;
            at[1] = pos.getY() + 1.3;
            at[2] = pos.getZ() + 0.5;
            found[0] = true;
        });
        if (!found[0]) {
            double yaw = Math.toRadians(player.getYRot());
            at[0] = player.getX() - Math.sin(yaw) * 1.5;
            at[1] = player.getY() + 1.3;
            at[2] = player.getZ() + Math.cos(yaw) * 1.5;
        }
        return at;
    }
}
