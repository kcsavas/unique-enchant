package fr.uniqueenchants;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Le livre flotte, tremble, fume... puis BOOM (2 secondes). */
public final class Animations {

    private static final int DURATION = 40; // ticks
    private static final List<BookExplosion> RUNNING = new ArrayList<>();

    private Animations() {}

    public static void startBookExplosion(ServerPlayer player, double x, double y, double z, ItemStack book) {
        RUNNING.add(new BookExplosion((ServerLevel) player.level(), player, x, y, z, book));
    }

    public static void tick() {
        Iterator<BookExplosion> it = RUNNING.iterator();
        while (it.hasNext()) {
            if (it.next().tick()) it.remove();
        }
    }

    /** À l'arrêt du serveur : on retire les livres en vol pour ne rien sauvegarder dans le monde. */
    public static void clear() {
        for (BookExplosion b : RUNNING) b.cleanup();
        RUNNING.clear();
    }

    private static final class BookExplosion {
        private final ServerLevel level;
        private final ServerPlayer player;
        private final double x, y, z;
        private final ItemStack book;
        private ItemEntity item;
        private int tick = 0;

        BookExplosion(ServerLevel level, ServerPlayer player, double x, double y, double z, ItemStack book) {
            this.level = level;
            this.player = player;
            this.x = x;
            this.y = y;
            this.z = z;
            this.book = book;
        }

        boolean tick() {
            if (item == null) {
                item = new ItemEntity(level, x, y, z, book);
                item.setNeverPickUp();
                item.setUnlimitedLifetime();
                item.setNoGravity(true);
                level.addFreshEntity(item);
            }
            tick++;

            // On ferme l'enclume pour que le joueur voie la scène
            if (tick == 2) player.closeContainer();

            double shake = 0.02 + tick * 0.003; // tremble de plus en plus fort
            double px = x + (level.getRandom().nextDouble() - 0.5) * shake * 2;
            double py = y + tick * 0.012;
            double pz = z + (level.getRandom().nextDouble() - 0.5) * shake * 2;
            item.setPos(px, py, pz);

            level.sendParticles(ParticleTypes.ENCHANT, px, py, pz, 4, 0.4, 0.3, 0.4, 0.4);
            if (tick > 20) level.sendParticles(ParticleTypes.SMOKE, px, py, pz, 2, 0.1, 0.1, 0.1, 0.01);
            if (tick > 30) level.sendParticles(ParticleTypes.FLAME, px, py, pz, 3, 0.15, 0.15, 0.15, 0.02);
            if (tick % 5 == 0) {
                level.playSound(null, px, py, pz, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS,
                        0.8f, 0.5f + (tick / (float) DURATION) * 1.5f);
            }

            if (tick >= DURATION) {
                cleanup();
                if (Config.explosionPower > 0) {
                    level.explode(null, px, py, pz, Config.explosionPower,
                            Config.explosionBreakBlocks ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
                } else {
                    level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, px, py, pz, 1, 0, 0, 0, 0);
                }
                return true;
            }
            return false;
        }

        void cleanup() {
            if (item != null && !item.isRemoved()) item.discard();
        }
    }
}
