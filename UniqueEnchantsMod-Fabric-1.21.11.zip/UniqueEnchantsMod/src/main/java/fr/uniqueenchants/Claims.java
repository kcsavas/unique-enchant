package fr.uniqueenchants;

import net.minecraft.core.Holder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Registre des enchantements déjà pris. Fichier : <monde>/uniqueenchants_claims.txt (une ligne "clé=joueur"). */
public final class Claims {

    private static final Logger LOGGER = LoggerFactory.getLogger(UniqueEnchantsMod.MOD_ID);
    private static final Map<String, String> CLAIMS = new LinkedHashMap<>();
    private static Path file;

    private Claims() {}

    public static void load(MinecraftServer server) {
        CLAIMS.clear();
        file = server.getWorldPath(LevelResource.ROOT).resolve("uniqueenchants_claims.txt");
        if (!Files.exists(file)) return;
        try {
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                int i = line.lastIndexOf('=');
                if (i > 0) CLAIMS.put(line.substring(0, i), line.substring(i + 1));
            }
        } catch (IOException e) {
            LOGGER.error("Lecture de {} impossible : {}", file, e.getMessage());
        }
    }

    public static void unload() {
        CLAIMS.clear();
        file = null;
    }

    /** Ex : "minecraft:protection:4" (ou "minecraft:protection" si unique_per_level=false). */
    public static String keyOf(Holder<Enchantment> ench, int level) {
        String k = ench.getRegisteredName();
        return Config.uniquePerLevel ? k + ":" + level : k;
    }

    public static boolean isClaimed(String key) {
        return CLAIMS.containsKey(key);
    }

    public static boolean anyClaimed(Collection<String> keys) {
        for (String k : keys) if (CLAIMS.containsKey(k)) return true;
        return false;
    }

    public static void claimAll(Collection<String> keys, String who) {
        if (keys.isEmpty()) return;
        for (String k : keys) CLAIMS.putIfAbsent(k, who);
        save();
    }

    private static void save() {
        if (file == null) return;
        List<String> lines = new ArrayList<>();
        CLAIMS.forEach((k, v) -> lines.add(k + "=" + v));
        try {
            Files.write(file, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            LOGGER.error("Écriture de {} impossible : {}", file, e.getMessage());
        }
    }
}
