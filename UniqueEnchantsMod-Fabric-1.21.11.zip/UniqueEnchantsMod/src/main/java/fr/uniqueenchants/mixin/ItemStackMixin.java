package fr.uniqueenchants.mixin;

import fr.uniqueenchants.Config;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

    @Unique
    private ItemStack uniqueenchants$backup;

    /** Infinity sur un consommable : on garde une copie avant qu'il soit consommé... */
    @Inject(method = "finishUsingItem", at = @At("HEAD"))
    private void uniqueenchants$before(Level level, LivingEntity entity, CallbackInfoReturnable<ItemStack> cir) {
        this.uniqueenchants$backup = null;
        if (!Config.infiniteFood || level.isClientSide() || !(entity instanceof Player)) return;

        ItemStack self = (ItemStack) (Object) this;
        ItemEnchantments enchants = self.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
        for (Holder<Enchantment> h : enchants.keySet()) {
            if (h.is(Enchantments.INFINITY)) {
                this.uniqueenchants$backup = self.copy();
                return;
            }
        }
    }

    /** ... et on la rend à la place du reste : la pomme dorée revient toujours. */
    @Inject(method = "finishUsingItem", at = @At("RETURN"), cancellable = true)
    private void uniqueenchants$after(Level level, LivingEntity entity, CallbackInfoReturnable<ItemStack> cir) {
        if (this.uniqueenchants$backup != null) {
            cir.setReturnValue(this.uniqueenchants$backup);
            this.uniqueenchants$backup = null;
        }
    }
}
