package fr.uniqueenchants.mixin;

import fr.uniqueenchants.AnvilLogic;
import fr.uniqueenchants.Claims;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

@Mixin(AnvilMenu.class)
public abstract class AnvilMenuMixin {

    @Shadow @Final private DataSlot cost;
    @Shadow private String itemName;

    /** Après le calcul vanilla : on remplace par un résultat où tout est permis. */
    @Inject(method = "createResult", at = @At("RETURN"))
    private void uniqueenchants$createResult(CallbackInfo ci) {
        AnvilMenu self = (AnvilMenu) (Object) this;
        if (!(((ItemCombinerMenuAccessor) (Object) self).getPlayer() instanceof ServerPlayer)) return;

        AnvilLogic.Built built = AnvilLogic.build(
                self.getSlot(0).getItem(),
                self.getSlot(1).getItem(),
                self.getSlot(2).getItem(),
                this.itemName);
        if (built == null) return;

        self.getSlot(2).set(built.result());
        this.cost.set(built.cost());
    }

    /** Le joueur récupère vraiment le résultat : on "prend" les enchantements. */
    @Inject(method = "onTake", at = @At("HEAD"))
    private void uniqueenchants$onTake(Player player, ItemStack stack, CallbackInfo ci) {
        if (!(player instanceof ServerPlayer)) return;
        AnvilMenu self = (AnvilMenu) (Object) this;

        Set<String> keys = AnvilLogic.consumedKeys(self.getSlot(0).getItem(), self.getSlot(1).getItem(), stack);
        Claims.claimAll(keys, player.getName().getString());
    }
}
