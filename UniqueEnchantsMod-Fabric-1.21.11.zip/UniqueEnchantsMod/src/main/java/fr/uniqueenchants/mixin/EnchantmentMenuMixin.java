package fr.uniqueenchants.mixin;

import fr.uniqueenchants.AnvilLogic;
import fr.uniqueenchants.Claims;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

@Mixin(EnchantmentMenu.class)
public abstract class EnchantmentMenuMixin {

    /**
     * Table d'enchantement : après l'enchantement, on retire ce qui était déjà pris
     * et on enregistre le reste. (require = 0 : si la signature change, le mod démarre quand même.)
     */
    @Inject(method = "clickMenuButton", at = @At("RETURN"), require = 0)
    private void uniqueenchants$afterEnchant(Player player, int id, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue() || !(player instanceof ServerPlayer sp)) return;

        EnchantmentMenu self = (EnchantmentMenu) (Object) this;
        ItemStack stack = self.getSlot(0).getItem();
        if (stack.isEmpty()) return;

        Set<Holder<Enchantment>> taken = new HashSet<>();
        for (Object2IntMap.Entry<Holder<Enchantment>> e : AnvilLogic.enchantsOf(stack).entrySet()) {
            if (Claims.isClaimed(Claims.keyOf(e.getKey(), e.getIntValue()))) taken.add(e.getKey());
        }
        if (!taken.isEmpty()) {
            EnchantmentHelper.updateEnchantments(stack, mut -> mut.removeIf(taken::contains));
            self.getSlot(0).setChanged();
            sp.sendSystemMessage(Component.literal("Certains enchantements étaient déjà pris, ils ont disparu.")
                    .withStyle(ChatFormatting.RED));
        }

        Set<String> keys = new LinkedHashSet<>();
        for (Object2IntMap.Entry<Holder<Enchantment>> e : AnvilLogic.enchantsOf(stack).entrySet())
            keys.add(Claims.keyOf(e.getKey(), e.getIntValue()));
        Claims.claimAll(keys, sp.getName().getString());
    }
}
