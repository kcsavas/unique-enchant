package fr.uniqueenchants.mixin;

import fr.uniqueenchants.AnvilLogic;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ClickType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerMenu.class)
public abstract class AbstractContainerMenuMixin {

    /** Clic sur le slot résultat (2) d'une enclume : si l'enchantement est déjà pris -> animation + explosion. */
    @Inject(method = "clicked", at = @At("HEAD"), cancellable = true)
    private void uniqueenchants$anvilClick(int slotId, int button, ClickType clickType, Player player, CallbackInfo ci) {
        if (slotId != 2 || clickType == ClickType.QUICK_CRAFT) return;
        if (!((Object) this instanceof AnvilMenu anvil) || !(player instanceof ServerPlayer sp)) return;

        if (AnvilLogic.blockIfUsed(anvil, sp)) ci.cancel();
    }
}
