package fr.uniqueenchants;

import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Fichier : config/uniqueenchants.properties */
public final class Config {

    private static final Logger LOGGER = LoggerFactory.getLogger(UniqueEnchantsMod.MOD_ID);

    /** true : unique PAR NIVEAU (Protection 4 pris, Protection 3 reste dispo). false : unique tout court. */
    public static boolean uniquePerLevel = true;
    /** Infinity sur un consommable = il ne disparait jamais. */
    public static boolean infiniteFood = true;
    /** 0 = juste des particules, sans dégâts. */
    public static float explosionPower = 1.2f;
    public static boolean explosionBreakBlocks = false;

    private Config() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("uniqueenchants.properties");
        Properties p = new Properties();
        try {
            if (Files.exists(file)) {
                try (Reader in = Files.newBufferedReader(file)) {
                    p.load(in);
                }
            }
            uniquePerLevel = Boolean.parseBoolean(p.getProperty("unique_per_level", "true"));
            infiniteFood = Boolean.parseBoolean(p.getProperty("infinite_food", "true"));
            explosionPower = Float.parseFloat(p.getProperty("explosion_power", "1.2"));
            explosionBreakBlocks = Boolean.parseBoolean(p.getProperty("explosion_break_blocks", "false"));

            p.setProperty("unique_per_level", String.valueOf(uniquePerLevel));
            p.setProperty("infinite_food", String.valueOf(infiniteFood));
            p.setProperty("explosion_power", String.valueOf(explosionPower));
            p.setProperty("explosion_break_blocks", String.valueOf(explosionBreakBlocks));
            try (Writer out = Files.newBufferedWriter(file)) {
                p.store(out, "UniqueEnchants");
            }
        } catch (IOException | NumberFormatException e) {
            LOGGER.error("Config illisible, valeurs par défaut utilisées : {}", e.getMessage());
        }
    }
}
