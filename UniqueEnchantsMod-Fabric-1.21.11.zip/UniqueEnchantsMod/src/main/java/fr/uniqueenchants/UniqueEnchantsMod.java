package fr.uniqueenchants;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public final class UniqueEnchantsMod implements ModInitializer {

    public static final String MOD_ID = "uniqueenchants";

    @Override
    public void onInitialize() {
        Config.load();

        // Les enchantements pris sont stockés dans le dossier du monde
        ServerLifecycleEvents.SERVER_STARTED.register(Claims::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> Animations.clear());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> Claims.unload());

        ServerTickEvents.END_SERVER_TICK.register(server -> Animations.tick());
    }
}
